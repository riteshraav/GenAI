class ChatWithDocModel{
  final String prompt;
  final String? response;
  final String role;

  ChatWithDocModel({required this.prompt, this.response, required this.role});

}