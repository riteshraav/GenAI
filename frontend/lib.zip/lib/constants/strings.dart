class AppStrings{
  static const String wisnolect = "WISNOLECT"; 
}