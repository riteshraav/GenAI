import 'package:arlex_getx/models/api_model.dart';
import 'package:arlex_getx/services/firebase_service.dart';
import 'package:arlex_getx/utils/custom_snackbar.dart';
import 'package:get/get.dart';

class ApiService extends GetxController {
  List<ApiModel> apiModel = [];
  @override
  Future<void> onInit() async {
    super.onInit();
    final model = await getApisFromFirebase();
    apiModel.add(model);
  }

  Future<ApiModel> getApisFromFirebase() async {
    try {
      final doc =
          await FirebaseService.firestore.collection("APIs").doc('api').get();
      return ApiModel.fromMap(doc.data()!);
    } catch (e) {
      CustomSnackbar.showError("Error!", "Something went wrong!");
      return ApiModel(
          geminiApi: "", imageGenApi: "", uploadDocApi: "", chatWithDocApi: "");
    }
  }
}
